#ifndef SECRET_H
#define SECRET_H

#define SECRET 'S'

#endif
