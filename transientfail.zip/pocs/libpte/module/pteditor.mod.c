#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xd568ff37, "module_layout" },
	{ 0x71d10f17, "remove_proc_entry" },
	{ 0xdd4253c7, "unregister_kretprobe" },
	{ 0x574ed504, "misc_deregister" },
	{ 0x65d9d25b, "proc_create" },
	{ 0x41b7e8e2, "register_kretprobe" },
	{ 0xce45afd5, "misc_register" },
	{ 0x63026490, "unregister_kprobe" },
	{ 0xfcca5424, "register_kprobe" },
	{ 0x92997ed8, "_printk" },
	{ 0x4c9d28b0, "phys_base" },
	{ 0xce807a25, "up_write" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x57bc19d2, "down_write" },
	{ 0x21271fd0, "copy_user_enhanced_fast_string" },
	{ 0x1f199d24, "copy_user_generic_string" },
	{ 0xecdcabd2, "copy_user_generic_unrolled" },
	{ 0xa648e561, "__ubsan_handle_shift_out_of_bounds" },
	{ 0x9a10294e, "__mmap_lock_do_trace_acquire_returned" },
	{ 0x8e3611b2, "__mmap_lock_do_trace_released" },
	{ 0x93075561, "__mmap_lock_do_trace_start_locking" },
	{ 0x53b954a2, "up_read" },
	{ 0xeccb6ba3, "__tracepoint_mmap_lock_released" },
	{ 0x6d046415, "__tracepoint_mmap_lock_acquire_returned" },
	{ 0x668b19a1, "down_read" },
	{ 0x55de20c8, "__tracepoint_mmap_lock_start_locking" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0xdad13544, "ptrs_per_p4d" },
	{ 0x8a35b432, "sme_me_mask" },
	{ 0x1d19f77b, "physical_mask" },
	{ 0x72d79d83, "pgdir_shift" },
	{ 0x54b1fac6, "__ubsan_handle_load_invalid_value" },
	{ 0x63f835ba, "on_each_cpu_cond_mask" },
	{ 0x5a5a2271, "__cpu_online_mask" },
	{ 0x670ecece, "__x86_indirect_thunk_rbx" },
	{ 0xfe08ce5b, "pid_task" },
	{ 0x8618d1d, "find_vpid" },
	{ 0x3ab58739, "current_task" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0xcb72d5c7, "pv_ops" },
	{ 0xa92ec74, "boot_cpu_data" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xbdfb6dbb, "__fentry__" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "5C7F959E82826A9B8C4FBD4");
